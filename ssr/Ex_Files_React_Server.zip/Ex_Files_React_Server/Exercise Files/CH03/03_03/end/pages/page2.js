const page2 = () => (
    <h1>I'm page 2</h1>
);

export default page2;
