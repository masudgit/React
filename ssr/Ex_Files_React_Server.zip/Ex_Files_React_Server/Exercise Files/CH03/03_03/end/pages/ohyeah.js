const ohyeah = () => (
    <h1>I'm page 3 trapped inside of OH YEAH!!</h1>
);

export default ohyeah;
